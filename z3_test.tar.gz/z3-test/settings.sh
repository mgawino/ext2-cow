#!/bin/sh

IMG=/test.img
IMG_SZ=128M
MOUNT_POINT=/mnt/test_img

#set -x
